[Plugin] Cordova RevMob

1.Overview

show revmob popup, link, banner, full screen (including accepts video option) ad

[android, ios] [crosswalk] [cordova cli]

requires revmob account https://www.revmobmobileadnetwork.com

revmob-android-sdk-7.0.0
revmob-ios-sdk-8.1.0

2.Change log

1.0.4
	Modified capx examples
1.0.5
	Update SDK (android and ios)
1.0.6
	Modified capx examples
1.0.7
	Moved to video category.
1.0.10
	Added "Preload full screen ad" action
	Added License info property section (you can get license info from member area)
	
3.Install plugin

How to install c2 plugin
https://plus.google.com/102658703990850475314/posts/gKsjX72Fhud

4.Server setting

test mode setting: 
https://www.revmobmobileadnetwork.com - Monetization - [specific app] - Edit Media - Testing Mode: select one among Off, With Ads and Without Ads 

5.API

//actions
Preload banner ad
Show banner ad
Reload banner ad
Hide banner ad
Preload full screen ad
Show full screen ad: (including accepts video option: https://www.revmobmobileadnetwork.com - Monetization - [specific app] - Fullscreen - Edit - check Accepts Video or not)
Preload popup ad
Show popup ad
Preload ad link ad
Show ad link ad

//events
On banner ad preloaded
On banner ad loaded
On full screen ad preloaded
On full screen ad loaded
On full screen ad shown
On full screen ad hidden
On popup ad preloaded
On popup ad loaded
On popup ad shown
On popup ad hidden
On ad link ad preloaded
On ad link ad loaded
On ad link ad shown
On ad link ad hidden

6.Examples

example capx are included in doc folder

7.Test

Youtube
[![](http://img.youtube.com/vi/fThTXn88dNw/0.jpg)](https://www.youtube.com/watch?v=fThTXn88dNw&feature=youtu.be "Youtube")

CordovaApp-debug.apk
https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.revmob/blob/master/doc/CordovaApp-debug.apk

8.Useful links

How to fix build error
https://plus.google.com/102658703990850475314/posts/FHsiUrvZXWT

How to cordova
https://plus.google.com/102658703990850475314/posts/jK2EFRyzRG7

Cordova related c2 plugins (+crosswalk) support cummunity
https://plus.google.com/communities/117978754675005605917
