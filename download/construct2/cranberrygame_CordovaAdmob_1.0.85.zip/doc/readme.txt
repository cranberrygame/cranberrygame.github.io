[Plugin] Cordova Admob

1.Overview

show admob banner and full screen ad

[android, ios, wp8] [crosswalk] [phonegap cli]

requires admob account http://www.google.com/ads/admob/

com.google.playservices@21.0.0
GoogleMobileAdsSdkiOS-7.1.0

fix Admob SDK FPS issue: go to your AdMob account and disable text banners, leaving enabled only image banners. (provided by Cipriux)
(not both, but one of them)

fix crosswalk ios not supporting landscape issue:
first, lock screen orientation by using Phonegap ScreenOrientation (Auto lock screen orientation property: Landscape)
second, Admob SDK does not support smart banner size in this case, so use banner size in "Show banner ad" action.
see doc/example_phonegapadmob_advanced_banner+fullscreen_game over_1-2_multiplatform_requires ad unit.capx

fix wp8 issue:
if you use CordovaAdmob in "On start of layout" of first layout, put System.Wait 1.0 seconds before CordovaAdmob (if you does not put this, Phonegap Admob does not show ad on wp8)
Phonegap Admob does not support smart banner ad on wp8

icon provided by rekjl

2.Change log

1.0.74
	Modified capx examples
1.0.75
	Modified capx examples
1.0.76
	Modified capx examples
1.0.77
	Changed default banner position from top center to bottom center.
	Modified capx examples
1.0.78
	Modified capx examples
1.0.81
	Updated Admob ios SDK to version 7.1.0
	Added License info property section (you can get license info from member area)
	
3.Install plugin

How to install c2 plugin
https://plus.google.com/102658703990850475314/posts/gKsjX72Fhud

4.Server setting

<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/ad_unit1.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/ad_unit2.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/ad_unit3.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/ad_unit4.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/ad_unit5.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/ad_unit6.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/ad_unit7.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/ad_unit8.png"><br>

cf)심사를 위해 제출:

Export Compliance
	Have you added or made changes to encryption features since your last submission of this app? (No)

콘텐츠 권한
	App에 타사 콘텐츠가 포함 또는 표시되거나, App에서 타사 콘텐츠에 액세스할 수 있습니까? (No)

Advertising Identifier
	Does this app use the Advertising Identifier (IDFA)? (Yes)
	
	This app uses the Advertising Identifier to (select all that apply):
		Serve advertisements within the app (check)
	
	Limit Ad Tracking setting in iOS (check)	
	
5.API

//actions
Preload banner ad
Show banner ad
Reload banner ad
Hide banner ad
Preload full screen ad
Show full screen ad

//events
On banner ad preloaded
On banner ad loaded
On full screen ad preloaded
On full screen ad loaded
On full screen ad shown
On full screen ad hidden

6.Examples

example capx are included in doc folder

7.Test

Youtube
[![](http://img.youtube.com/vi/xXrVb8E8gMM/0.jpg)](https://www.youtube.com/watch?v=xXrVb8E8gMM&feature=youtu.be "Youtube")

CordovaApp-debug.apk
https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.admob/blob/master/doc/CordovaApp-debug.apk

8.Useful links

How to fix build error
https://plus.google.com/102658703990850475314/posts/FHsiUrvZXWT

How to cordova
https://plus.google.com/102658703990850475314/posts/jK2EFRyzRG7

Construct2 monetisation related plugins by cordova G+ community
https://plus.google.com/communities/117978754675005605917
