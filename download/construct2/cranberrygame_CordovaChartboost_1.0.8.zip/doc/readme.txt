[Plugin] Cordova Chartboost

1.Overview

show chartboost full screen (static interstitial, video interstial), more apps, rewarded video ad

[android, ios] [crosswalk] [cordova cli]

requires chartboost account https://www.chartboost.com

Chartboost android SDK 5.2.0 (Apr. 6, 2015)
Chartboost ios SDK 5.2.1 (Apr. 13, 2015)

I can't see any ads in my game - create a new publishing campaign in the Chartboost dashboard (takes 20 minutes to take effect)
https://answers.chartboost.com/hc/en-us/articles/201121969-I-can-t-see-any-ads-in-my-game

2.Change log

3.Install plugin

How to install c2 plugin
https://plus.google.com/102658703990850475314/posts/gKsjX72Fhud

4.Server setting

<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.chartboost/blob/master/doc/app_id.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.chartboost/blob/master/doc/publishing_campaign1.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.chartboost/blob/master/doc/publishing_campaign2.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.chartboost/blob/master/doc/publishing_campaign3.png"><br>
<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.chartboost/blob/master/doc/publishing_campaign4.png">

test mode setting: 
https://www.chartboost.com - Login - DASHBOARD - [specific app] - App Settings - Test Mode: select Disabled or Enabled 

5.API

//actions
Preload full screen ad
Show full screen ad: (static interstitial, video interstial)
Preload more apps ad
Show more apps ad: (more apps)
Preload rewarded video ad
Show rewarded video ad: (rewarded video)

//events
On full screen ad preloaded
On full screen ad shown
On full screen ad hidden
On more apps ad preloaded
On more apps ad shown
On more apps ad hidden
On rewarded video ad preloaded
On rewarded video ad shown
On rewarded video ad hidden
On rewarded video ad completed

6.Examples

example capx are included in doc folder

7.Test

<img src="https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.chartboost/blob/master/doc/fullscreen_ad.png">

Youtube
[![](http://img.youtube.com/vi/EQJLRbSKmPU/0.jpg)](https://www.youtube.com/watch?v=EQJLRbSKmPU&feature=youtu.be "Youtube")

CordovaApp-debug.apk
https://github.com/cranberrygame/com.cranberrygame.cordova.plugin.ad.chartboost/blob/master/doc/CordovaApp-debug.apk

8.Useful links

How to fix build error
https://plus.google.com/102658703990850475314/posts/FHsiUrvZXWT

How to cordova
https://plus.google.com/102658703990850475314/posts/jK2EFRyzRG7

Cordova related c2 plugins (+crosswalk) support cummunity
https://plus.google.com/communities/117978754675005605917
