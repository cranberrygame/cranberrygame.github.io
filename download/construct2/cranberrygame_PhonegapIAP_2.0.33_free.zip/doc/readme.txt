[Plugin] Phonegap IAP

1.Overview

in app purchase

[android, ios, wp8] [crosswalk] [phonegap cli]

requires google play developer account https://play.google.com/apps/publish/
requires apple developer account https://developer.apple.com/devcenter/ios/index.action
requires windows phone developer account https://dev.windowsphone.com/

wp8 is not yet supported

cf)

android: Phonegap IAP or c2 IAP plugin

blackberry10: c2 IAP plugin (https://www.scirra.com/manual/173/iap)

ios: Phonegap IAP or c2 IAP plugin

windows8: c2 IAP plugin

wp8: Phonegap IAP

2.Change log

2.0.31
	Modified capx example
2.0.32
	Modified capx example
	Added capx example (example_phonegapiap_advanced_my key only if android.capx)
	
3.Install plugin

How to install c2 plugin
https://plus.google.com/102658703990850475314/posts/gKsjX72Fhud

4.Server setting

[android]

//if you see this message when trying to add in app product, you must republish the app with Phonegap IAP plugin once in alpha, beta, normal publish (just republish, no iap event coding).
//if your app is republished with dummy Phonegap IAP plugin, then you can add in app product
//(See 1.png 2.png 3.png)
Your app doesn't have any in-app products yet. 
To add in-app products, you need to add the BILLING permission to your APK.

//add in app product (nonconsumable)
google play developer console - [specific app] - in app product - add - managed, product ID: testapp_removeads - Name : Remove Ads, Description: Remove ads - set active

//add in app product (consumable)
google play developer console - [specific app] - in app product - add - unmanaged, product ID: testapp_coinpack1 - Name : Coin Pack1, Description: Coin pack1 - set active

//add in app product (consumable)
google play developer console - [specific app] - in app product - add - unmanaged, product ID: testapp_coinpack2 - Name : Coin Pack2, Description: Coin pack2 - set active

//add in app product (consumable)
google play developer console - [specific app] - in app product - add - unmanaged, product ID: testapp_coinpack3 - Name : Coin Pack3, Description: Coin pack3 - set active

//get application license key (per app)
google play developer console - [specific app] - Services & APis - license and in app purchase - get ANDROID_APPLICATION_LICENSE_KEY

[ios]

//add in app product (nonconsumable)
itunesconnect - Manage Your Apps - [specific app] - Manage In-App Purchases - Create New - Non Consumable - Select - Reference Name: testapp_removeads, Product ID: testapp_removeads - 언어 추가 - 언어: English, Display Name : Remove Ads, Description: Remove ads - Screenshot for Review (screen shot where PurchaseFullVersion button exists)

//add in app product (consumable)
itunesconnect - Manage Your Apps - [specific app] - Manage In-App Purchases - Create New - Consumable - Select - Reference Name: testapp_coinpack1, Product ID: testapp_coinpack1 - 언어 추가 - 언어: English, Display Name : Coin Pack1 (250 Coins), Description: Coin Pack1 (250 Coins) - Screenshot for Review (screen shot where PurchaseConsumablePack button exists)

//add in app product (consumable)
itunesconnect - Manage Your Apps - [specific app] - Manage In-App Purchases - Create New - Consumable - Select - Reference Name: testapp_coinpack2, Product ID: testapp_coinpack2 - 언어 추가 - 언어: English, Display Name : Coin Pack2 (750 Coins), Description: Coin Pack2 (750 Coins) - Screenshot for Review (screen shot where PurchaseConsumablePack button exists)

//add in app product (consumable)
itunesconnect - Manage Your Apps - [specific app] - Manage In-App Purchases - Create New - Consumable - Select - Reference Name: testapp_coinpack3, Product ID: testapp_coinpack3 - 언어 추가 - 언어: English, Display Name : Coin Pack3 (2250 Coins), Description: Coin Pack3 (2250 Coins) - Screenshot for Review (screen shot where PurchaseConsumablePack button exists)

cf)Screenshot for Review (Screenshots must be 960x640, 960x600, 640x960, 640x920, 1136x640, 1136x600, 640x1136, 640x1096, 2208x1242, 1242x2208, 1334x750, 750x1334, 1024x768, 1024x748, 768x1024, 768x1004, 2048x1536, 2048x1496, 1536x2048 or 1536x2008 pixels.)

iOS Simulator - Hardware - Device - iPhone 6 Plus

Screen capture (1242x2208)

See doc/iOS Simulator Screen Shot_iPhone 6 Plus.png

[wp8]

//add in app product (nonconsumable)
Windows Phone Dev Center - Dashboard - select Windows Phone Store - Apps - [specific app] - Products - Add in-app product - In-app product properties - In-app product alias: testapp_removeads, Product identifier: testapp_removeads, Product type: Durable, Product lifetime: Forever - Save -
Description - Product title: Remove Ads, Description: Remove ads, Product image: (300x300 px PNG file) - Save - Submit

//add in app product (consumable)
Windows Phone Dev Center - Dashboard - select Windows Phone Store - Apps - [specific app] - Products - Add in-app product - In-app product properties - In-app product alias: testapp_coinpack1, Product identifier: testapp_coinpack1, Product type: Consumable - Save -
Description - Product title: Coin Pack1 (250 Coins), Description: Coin Pack1 (250 Coins), Product image: (300x300 px PNG file) - Save - Submit

//add in app product (consumable)
Windows Phone Dev Center - Dashboard - select Windows Phone Store - Apps - [specific app] - Products - Add in-app product - In-app product properties - In-app product alias: testapp_coinpack2, Product identifier: testapp_coinpack2, Product type: Consumable - Save -
Description - Product title: Coin Pack2 (750 Coins), Description: Coin Pack2 (750 Coins), Product image: (300x300 px PNG file) - Save - Submit

//add in app product (consumable)
Windows Phone Dev Center - Dashboard - select Windows Phone Store - Apps - [specific app] - Products - Add in-app product - In-app product properties - In-app product alias: testapp_coinpack3, Product identifier: testapp_coinpack3, Product type: Consumable - Save -
Description - Product title: Coin Pack3 (2250 Coins), Description: Coin Pack3 (2250 Coins), Product image: (300x300 px PNG file) - Save - Submit

ing
//Get YOUR_APP_ID from Windows Phone Dev Center and put it in "your wp8 project - Properties - WMAppManifest.xml - Packaging - Product ID"
Windows Phone Dev Center - Dashboard - select Windows Phone Store - Apps - [specific app] - Details - App ID: YOUR_APP_ID

5.API

//actions
Add product ID: 
Request store listing: get all products' infos which products we Add product IDs before.
Purchase product: purchase product id, put purchase product id info into server.
Consume product: consume product id, throw away purchase product id info from server.
Restore purchases: get user's purchased product ids which purchased before and not cunsumed.
Purchase app: purchase product id "app"

//events
On store listing success: success event of Request store listing
On store listing failed: failure event of Request store listing
On product purchase success: success event of Purchase product
On product purchase failed: failure event of Purchase product
On consume success: success event of Consume product
On consume failed: failure event of Consume product

//conditions
Has product: has product id, whether user purchased before and not consumed, available after purchase, consume or Restore purchases.
Is app purchased: has product id "app"
Is store available: 

6.Examples

example capx are included in doc folder

Winfried Voelkel's Seven Birds VS Mr. Monkey is very good real example for consumable IAP using Phonegap IAP plugin: https://play.google.com/store/apps/details?id=com.SevenBirdsVSMrMonkey

7.Test

[android] [crosswalk]

//publish as alpha test (recommend) or beta test instead of production.
google play developer console - [specific app] - APK - Alpha test - Upload as alpha test - Drag and drop apk and publish now as alpha test.

//add test user for iap
google play developer console - configuration - account detail - testing accounts (google play account)

//add test community for alpha test or beta test download
google play developer console - 
All applications - 
[specific app] - 
APK -
Alpha testers - 
Manage list of testers - 
Add Google groups or Google+ community: https://plus.google.com/communities/xxx (if you want make Google+ Community, go to this: https://plus.google.com/communities) -
Add - 
Let test user download and install apk from this url: https://play.google.com/apps/testing/YOUR_PACKAGE (invite test user in your Google+ community, wait until this url is available, take hours)

test for iap requires real device.

cf)caution 

if you want to test with local apk, use signed and exactly same version apk uploaded in google play store.

cf)error message

the item you requested is not available for purchase
==> In-activated Product Id, so Activate Product Id
http://stackoverflow.com/questions/13117081/the-item-you-requested-is-not-available-for-purchase

[ios]

test doest not requires publishing.
test requires real device.

//if you don't want to spend real money buying your own app, setup your test users and buy with test account.
//if you alreay logged in with other account, first log out (Setting - iTunes & App Store - App ID: xxx@xxx.com - Log out)
itunesconnect - Users and Roles - Sandbox Testers - +

//Xdk
XDK PROJECTS - projectname - BUILD SETTINGS - iOS - Provisioning Profile: production, Production Provisioning File: YOUR_PROVISION_FILE (.mobileprovision)
BUILD - CORVOVA 3,X HYBRID MOBILE APP PLATFORMS - iOS - Build - iOS CERTIFICATE - Edit - UPLOAD CERTIFICATE: YOUR_CERTIFICATE_FILE (.cer) - Go to Next Step - Download .ipa file - Drag it to the itunes and run it on the device

//Xcode
Select "Xcode - iPhone" (Ad Hoc)
- Product
- Run

[wp8]

8.Useful links

1)

How to fix build error
https://plus.google.com/102658703990850475314/posts/FHsiUrvZXWT

How to cordova
https://plus.google.com/102658703990850475314/posts/jK2EFRyzRG7

Cordova related c2 plugins (+crosswalk) support cummunity
https://plus.google.com/communities/117978754675005605917

2)

How to upload and download an Alpha or Beta app to Google Play
https://www.scirra.com/tutorials/1287/how-to-upload-and-download-an-alpha-or-beta-app-to-google-play

Use alpha/beta testing & staged rollouts (android)
https://support.google.com/googleplay/android-developer/answer/3131213?hl=en

In-App Purchase on Google Play (Android) using CocoonJS (android)
https://www.scirra.com/tutorials/645/in-app-purchase-on-google-play-android-using-cocoonjs/page-1

Testing In-app Billing (android)
http://developer.android.com/google/play/billing/billing_testing.html

3 Steps Tutorial for PhoneGap In-App Purchase on iOS (ios)
http://fovea.cc/blog/index.php/3-steps-tutorial-for-phonegap-in-app-purchase-on-ios/

Implementing In-App Purchase on Windows Phone 8
http://code.tutsplus.com/tutorials/implementing-in-app-purchase-on-windows-phone-8--cms-22593

Increase your revenue with In-App Purchase on Windows Phone 8
http://developer.nokia.com/community/wiki/Increase_your_revenue_with_In-App_Purchase_on_Windows_Phone_8

Beta testing your app and in-app products (wp8)
http://msdn.microsoft.com/library/windows/apps/jj215598(v=vs.105).aspx

IAP object
https://www.scirra.com/manual/173/iap
