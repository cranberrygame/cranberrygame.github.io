[Plugin] Phonegap Game

1.Overview

show leaderboard and achievements (google play game and game center, SDK)

[android, ios] [crosswalk] [phonegap cli]

requires google play developer account https://play.google.com/apps/publish/
requires apple developer account https://developer.apple.com/devcenter/ios/index.action

cf)

Leaderboard game: Best score game
	Limited life
		ex) 1, 3
	Limited time
		ex) 30 seconds
	Time is score
	
Achievement
	Score
		ex)	Achievement1 (Score 10)
			Achievement2 (Score 30)
			Achievement3 (Score 60)
			Achievement4 (Score 100)
			Achievement5 (Score 150)
	Level
		ex)	Achievement1 (Level 1)
			Achievement2 (Level 2)
			Achievement3 (Level 4)
			Achievement4 (Level 6)
			Achievement5 (Level 8)
			Achievement6 (Level 10)
	Category
		ex)	Achievement1 (Number)
			Achievement1 (Fruit)
			Achievement1 (Color)
			Achievement1 (Other)
			Achievement1 (Challenge (Limited time))

2.Change log

1.0.57
	Added "Android google play game app id" property in c2
1.0.58
	Modified example capx
1.0.59
	Modified example capx
1.0.60
	Modified example capx
1.0.61
	Modified example capx
1.0.62
	Modified readme.txt
1.0.63
	Fixed _getPlayerImage() NullPointerException issue
	Modified readme.txt
	Modified example capx
1.0.64
	Added system.save game example capx (example_phonegapgame_system_save game.capx)

3.Install plugin

How to install c2 plugin
https://plus.google.com/102658703990850475314/posts/gKsjX72Fhud
			
4.Server setting

[android]

//(See 1.png 2.png 3.png 4.png 5.png 6.png 7.png 8.png 9.png)

//add game
google play developer console - Game services - Add a new game - Enter the name of your game: Test App, Category: Puzzle

//get YOUR_GOOGLE_PLAY_GAME_APP_ID
google play developer console - Game services - [specific app] - get YOUR_GOOGLE_PLAY_GAME_APP_ID (the number that appears beside the game name in the header of the Developer Console, e.g. "Test App - 12345678",. The YOUR_GOOGLE_PLAY_GAME_APP_ID in this case is 12345678.)

//link app
google play developer console - Game services - [specific app] - Linked App - Android - Save and continue - Authorize your app now - Continue - Create Client (if Signing certificate fingerprint (SHA1) is blank, do it after publishing app in alpha, beta, or normal (after publishing, it will be filled automatically))

//add leaderboard, get YOUR_GOOGLE_PLAY_GAME_LEADERBOARD_ID
google play developer console - Game services - [specific app] - leaderboard - Add leaderboard - Name: Leaderboard - get YOUR_GOOGLE_PLAY_GAME_LEADERBOARD_ID
 
//add achievements (must minimum 5 achievements), get YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID1, YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID2, YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID3, YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID4, YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID5
google play developer console - Game services - [specific app] - achievement - Add achievement - Name: Achievement1 (Score 10), Description: Achievement1 (Score 10) - get YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID1
google play developer console - Game services - [specific app] - achievement - Add achievement - Name: Achievement2 (Score 30), Description: Achievement2 (Score 30) - get YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID2
google play developer console - Game services - [specific app] - achievement - Add achievement - Name: Achievement3 (Score 60), Description: Achievement3 (Score 60) - get YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID3
google play developer console - Game services - [specific app] - achievement - Add achievement - Name: Achievement4 (Score 100), Description: Achievement4 (Score 100) - get YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID4
google play developer console - Game services - [specific app] - achievement - Add achievement - Name: Achievement5 (Score 150), Description: Achievement5 (Score 150) - get YOUR_GOOGLE_PLAY_GAME_ACHIEVEMENT_ID5

//publish game
google play developer console - Game services - [specific app] - prepare test - publish game

[ios]

itunesconnect - 나의 App - [specific app] - Game Center - Enable for Single Game

//leaderboard
itunesconnect - 나의 App - [specific app] - Game Center - Add Leaderboard -
단일 순위표 - 
순위표 세트 식별 정보: testapp_leaderboard - 
순위표 ID: testapp_leaderboard -
점수 형식 유형: Integer -
점수 제출 유형: 가장 높은 점수
정렬 순서: 높은 점수순 -
Add Language -
언어: English -
이름: Leaderboard -
점수 형식: Integer (100,000,122) -
Save

//achievement1
itunesconnect - 나의 App - [specific app] - Game Center - 목표 달성 추가 -
목표 달성 식별 정보: testapp_achievement1
목표 달성 ID: testapp_achievement1
점수 값: 25 (max 100)
숨김: No
여러 번 달성 가능: No
언어 추가 - 
언어: English 
제목: Achievement1 (Score 10)
사전 획득한 목표 달성 설명: Achievement1 (Score 10)
획득한 목표 달성 설명: Achievement1 (Score 10)
이미지: 512x512 png

//achievement2
itunesconnect - 나의 App - [specific app] - Game Center - 목표 달성 추가 -
목표 달성 식별 정보: testapp_achievement2
목표 달성 ID: testapp_achievement2
점수 값: 50 (max 100)
숨김: No
여러 번 달성 가능: No
언어 추가 - 
언어: English 
제목: Achievement2 (Score 30)
사전 획득한 목표 달성 설명: Achievement2 (Score 30)
획득한 목표 달성 설명: Achievement2 (Score 30)
이미지: 512x512 png

//achievement3
itunesconnect - 나의 App - [specific app] - Game Center - 목표 달성 추가 -
목표 달성 식별 정보: testapp_achievement3
목표 달성 ID: testapp_achievement3
점수 값: 75 (max 100)
숨김: No
여러 번 달성 가능: No
언어 추가 - 
언어: English 
제목: Achievement3 (Score 60)
사전 획득한 목표 달성 설명: Achievement3 (Score 60)
획득한 목표 달성 설명: Achievement3 (Score 60)
이미지: 512x512 png

//achievement4
itunesconnect - 나의 App - [specific app] - Game Center - 목표 달성 추가 -
목표 달성 식별 정보: testapp_achievement4
목표 달성 ID: testapp_achievement4
점수 값: 100 (max 100)
숨김: No
여러 번 달성 가능: No
언어 추가 - 
언어: English 
제목: Achievement4 (Score 100)
사전 획득한 목표 달성 설명: Achievement4 (Score 100)
획득한 목표 달성 설명: Achievement4 (Score 100)
이미지: 512x512 png

//achievement5
itunesconnect - 나의 App - [specific app] - Game Center - 목표 달성 추가 -
목표 달성 식별 정보: testapp_achievement5
목표 달성 ID: testapp_achievement5
점수 값: (leave blank, max 100)
숨김: No
여러 번 달성 가능: No
언어 추가 - 
언어: English 
제목: Achievement5 (Score 150)
사전 획득한 목표 달성 설명: Achievement5 (Score 150)
획득한 목표 달성 설명: Achievement5 (Score 150)
이미지: 512x512 png

can test before publish

5.API

//actions
Login
Logout
Get player image
Get player score
Submit score
Show leaderboard
Unlock achievement
Increment achievement: (achievementId, incrementalStepOrCurrentPercent: Incremental step (android) or current percent (ios) for incremental achievement.)
Show achievements
Reset achievements: (only supported on ios)

//events
On login succeeded
On login failed
On get player image succeeded
On get player image failed
On get player score succeeded
On get player score failed
On submit score succeeded
On submit score failed
On unlock achievement succeeded
On unlock achievement failed
On increment achievement succeeded
On increment achievement failed
On reset achievements succeeded
On reset achievements failed

//conditions
Is logged in

6.Examples

example capx are included in doc folder

7.Test

[android] [crosswalk]

//publish as alpha test (recommend) or beta test instead of production.
google play developer console - [specific app] - APK - Alpha test - Upload as alpha test - Drag and drop apk and publish now as alpha test.

//add test user for game
google play developer console - Game services - [specific game] - test - add tester (google play account)

//add test community for alpha test or beta test download
google play developer console - 
All applications - 
[specific app] - 
APK -
Alpha testers - 
Manage list of testers - 
Add Google groups or Google+ community: https://plus.google.com/communities/xxx (if you want make Google+ Community, go to this: https://plus.google.com/communities) -
Add - 
Let test user download and install apk from this url: https://play.google.com/apps/testing/YOUR_PACKAGE (invite test user in your Google+ community, wait until this url is available, take hours)

[ios]

iphone - Setting - Game Center - activate sand box mode - login with sand box account in the app

8.Useful links

How to fix build error
https://plus.google.com/102658703990850475314/posts/FHsiUrvZXWT

How to cordova
https://plus.google.com/102658703990850475314/posts/jK2EFRyzRG7

Cordova related c2 plugins (+crosswalk) support cummunity
https://plus.google.com/communities/117978754675005605917
