[Plugin] Phonegap Facebook

1.Overview

facebook login, wall post, publish score, top score, hi-score board

[android, ios] [crosswalk] [phonegap cli]

requires facebook developer account https://developers.facebook.com/apps

You can also use this plugin's AccessToken with lanceal's various facebook related plugins: https://www.scirra.com/forum/facebook_t111941

2.Change log

2.0.2
	Modified capx example
2.0.3
	Modified capx example
2.0.4
	Updated readme.txt
2.0.5
	Added Request Permission function and modified login to take string parameter of permissions (contributed by gizmodude4)
2.0.5.1
	Cleaned capx example
2.0.7.1
    1. fixed android-support-v4.jar build conflict with Phonegap Game problem. (so no need to use Phonegap FacebookPB (just use Phonegap Facebook))
    2.Added facebook share auto time line posting marketing example (example_phonegapfacebook_advanced_facebookshare_auto_requires id.capx)
	
3.Install plugin

How to install c2 plugin
https://plus.google.com/102658703990850475314/posts/gKsjX72Fhud

4.Server setting

[android]

https://developers.facebook.com/apps - Add a New App - ... - Skip Quick Start

Put your app id and your app name to Phonegap Facebook plugin's c2 property.

cf)How to get Key Hashes (facebook)

cd /d D:\sign\android
keytool -list -v -keystore mykey.keystore -alias mykeystore

SHA1: 90:2F:37:48:~~~~~~:09:2D:61:52:E6

convert upper SHA1 to base64 string for facebook from following site.
http://tomeko.net/online_tools/hex_to_base64.php?lang=en

==> Key Hashes: kC83~~~~~~~~~1hUuY=

5.API

//actions
Log in
Log out
Prompt wall post
Prompt to share this app
Prompt to share link
Publish wall post: (in short time, same contents can not be posted duplicately) (submit review for publish_actions permission)
Publish link: (in short time, same contents can not be posted duplicately) (submit review for publish_actions permission)
Publish score: (submit review for publish_actions permission)
Request user top score
Request hi-score board
Request Permissions

//events
On user logged in
On user logged out
On name available
On user top score available
On hi-score
On score submitted
On prompt wall post succeeded
On prompt wall post failed
On prompt to share this app succeeded
On prompt to share this app failed
On prompt to share link succeeded
On prompt to share link failed

//conditions
Is user logged in

6.Examples

example capx are included in doc folder

7.Test

8.Useful links

How to fix build error
https://plus.google.com/102658703990850475314/posts/FHsiUrvZXWT

How to cordova
https://plus.google.com/102658703990850475314/posts/jK2EFRyzRG7

Cordova related c2 plugins (+crosswalk) support cummunity
https://plus.google.com/communities/117978754675005605917
