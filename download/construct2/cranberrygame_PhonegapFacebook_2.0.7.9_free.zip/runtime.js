﻿// ECMAScript 5 strict mode
"use strict";

assert2(cr, "cr namespace not created");
assert2(cr.plugins_, "cr.plugins_ not created");

/*
//cranberrygame start: structure
cr.plugins_.cranberrygame_PhonegapFacebook = function(runtime)
{
	this.runtime = runtime;
	Type
		onCreate
	Instance
		onCreate
		draw
		drawGL		
	cnds
		//MyCondition
		//TriggerCondition
	acts
		//MyAction
		//TriggerAction
	exps
		//MyExpression
};		
//cranberrygame end: structure
*/

/////////////////////////////////////
// Plugin class
// *** CHANGE THE PLUGIN ID HERE *** - must match the "id" property in edittime.js
//          vvvvvvvv
cr.plugins_.cranberrygame_PhonegapFacebook = function(runtime)
{
	this.runtime = runtime;
};

(function ()
{
	/////////////////////////////////////
	// *** CHANGE THE PLUGIN ID HERE *** - must match the "id" property in edittime.js
	//                            vvvvvvvv
	var pluginProto = cr.plugins_.cranberrygame_PhonegapFacebook.prototype;
		
	/////////////////////////////////////
	// Object type class
	pluginProto.Type = function(plugin)
	{
		this.plugin = plugin;
		this.runtime = plugin.runtime;
	};

	var typeProto = pluginProto.Type.prototype;

/*
	//for example
	var fbAppID = "";
*/
//cranberrygame start
	var fbAppID = "";
	//var fbAppSecret = "";
	var fbReady = false;
	var fbLogined = false;
	var fbUserID = "";
//cranberrygame start: contributued by lancel
	var fbAccessToken = "";	
//cranberrygame end	
	var fbFullName = "";
	var fbFirstName = "";
	var fbLastName = "";
	var fbGender = "";
	var fbEmail = "";
	var fbInst = null;
//	var fbLoggingIn = false; //gizmodude4 //temporarily commented
	
	var fbScore = 0;
	var fbHiscoreName = "";
	var fbHiscoreUserID = 0;
	var fbRank = 0;
	
	var fbPerms = "";
	//
	var errorMessage = "";
	//
	var curTag = "";	
//cranberrygame end
	
	// called on startup for each object type
	typeProto.onCreate = function()
	{
		
/*			
		//cranberrygame
		var newScriptTag=document.createElement('script');
		newScriptTag.setAttribute("type","text/javascript");
		newScriptTag.setAttribute("src", "mylib.js");
		document.getElementsByTagName("head")[0].appendChild(newScriptTag);
		//cranberrygame
		var scripts=document.getElementsByTagName("script");
		var scriptExist=false;
		for(var i=0;i<scripts.length;i++){
			//alert(scripts[i].src);//http://localhost:50000/jquery-2.0.0.min.js
			if(scripts[i].src.indexOf("cordova.js")!=-1||scripts[i].src.indexOf("phonegap.js")!=-1){
				scriptExist=true;
				break;
			}
		}
		if(!scriptExist){
			var newScriptTag=document.createElement("script");
			newScriptTag.setAttribute("type","text/javascript");
			newScriptTag.setAttribute("src", "cordova.js");
			document.getElementsByTagName("head")[0].appendChild(newScriptTag);
		}
*/		
//cranberrygame start
		if(this.runtime.isBlackberry10 || this.runtime.isWindows8App || this.runtime.isWindowsPhone8 || this.runtime.isWindowsPhone81){
			var scripts=document.getElementsByTagName("script");
			var scriptExist=false;
			for(var i=0;i<scripts.length;i++){
				//alert(scripts[i].src);//http://localhost:50000/jquery-2.0.0.min.js
				if(scripts[i].src.indexOf("cordova.js")!=-1||scripts[i].src.indexOf("phonegap.js")!=-1){
					scriptExist=true;
					break;
				}
			}
			if(!scriptExist){
				var newScriptTag=document.createElement("script");
				newScriptTag.setAttribute("type","text/javascript");
				newScriptTag.setAttribute("src", "cordova.js");
				document.getElementsByTagName("head")[0].appendChild(newScriptTag);
			}
		}
//cranberrygame end		
	};

	/////////////////////////////////////
	// Instance class
	pluginProto.Instance = function(type)
	{
		this.type = type;
		this.runtime = type.runtime;
		
		// any other properties you need, e.g...
		// this.myValue = 0;
	};
	
	var instanceProto = pluginProto.Instance.prototype;

	// called whenever an instance is created
	instanceProto.onCreate = function()
	{
		// note the object is sealed after this call; ensure any properties you'll ever need are set on the object
		// e.g...
		// this.myValue = 0;
		
/*
		var self=this;
		window.addEventListener("resize", function () {//cranberrygame
			self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.TriggerCondition, self);
		});
*/
//cranberrygame start
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
		
		fbAppID = this.properties[0];
		//fbAppSecret = this.properties[2];
		fbInst = this;

		var self = this;
		//https://github.com/Wizcorp/phonegap-facebook-plugin/blob/024b6ed1c83027ce18b6a05a188114beff9f6440/platforms/android/assets/www/index.html
		document.addEventListener('deviceready',function(){
			//alert('deviceready');

			fbReady = true;
			
			self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnReady, self);
		}, false);
//cranberrygame end			
	};
	
	// only called if a layout object - draw to a canvas 2D context
	instanceProto.draw = function(ctx)
	{
	};
	
	// only called if a layout object in WebGL mode - draw to the WebGL context
	// 'glw' is not a WebGL context, it's a wrapper - you can find its methods in GLWrap.js in the install
	// directory or just copy what other plugins do.
	instanceProto.drawGL = function (glw)
	{
	};

/*
	instanceProto.at = function (x)
	{
		return this.arr[x];
	};
	
	instanceProto.set = function (x, val)
	{
		this.arr[x] = val;
	};
*/	
//cranberrygame start
//cranberrygame end
	
	//////////////////////////////////////
	// Conditions
	function Cnds() {};

/*
	// the example condition
	Cnds.prototype.MyCondition = function (myparam)
	{
		// return true if number is positive
		return myparam >= 0;
	};

	//cranberrygame
	Cnds.prototype.TriggerCondition = function ()
	{
		return true;
	};
*/
	
//cranberrygame start
	Cnds.prototype.IsReady = function ()
	{
		return fbReady;
	};
	
	Cnds.prototype.OnReady = function ()
	{
		return true;
	};
	
	Cnds.prototype.IsLogined = function ()
	{
		return fbLogined;
	};
	
	Cnds.prototype.OnLoginSucceeded = function (tag)
	{
		return cr.equals_nocase(tag, curTag);
	};
	
	Cnds.prototype.OnLogoutSucceeded = function ()
	{
		return true;
	};
	
	Cnds.prototype.OnNameAvailable = function ()
	{
		return true;
	};
	
	Cnds.prototype.OnUserTopScoreAvailable = function ()
	{
		return true;
	};
	
	Cnds.prototype.OnHiscore = function ()
	{
		return true;
	};
	
	Cnds.prototype.OnPublishScoreSucceeded = function ()
	{
		return true;
	};
	//
	Cnds.prototype.OnPromptWallPostSucceeded = function ()
	{
		return true;
	};
	Cnds.prototype.OnPromptWallPostFailed = function ()
	{
		return true;
	};
	Cnds.prototype.OnPromptToShareThisAppSucceeded = function ()
	{
		return true;
	};
	Cnds.prototype.OnPromptToShareThisAppFailed = function ()
	{
		return true;
	};
	Cnds.prototype.OnPromptToShareLinkSucceeded = function ()
	{
		return true;
	};
	Cnds.prototype.OnPromptToShareLinkFailed = function ()
	{
		return true;
	};
	//
	Cnds.prototype.OnPublishWallPostSucceeded = function ()
	{
		return true;
	};	
	Cnds.prototype.OnPublishWallPostFailed = function ()
	{
		return true;
	};	
	Cnds.prototype.OnPublishLinkSucceeded = function ()
	{
		return true;
	};	
	Cnds.prototype.OnPublishLinkFailed = function ()
	{
		return true;
	};	
	Cnds.prototype.OnPublishScoreFailed = function ()
	{
		return true;
	};
	//
	Cnds.prototype.OnLoginFailed = function (tag)
	{
		return cr.equals_nocase(tag, curTag);
	};
	Cnds.prototype.OnLogoutFailed = function ()
	{
		return true;
	};
	Cnds.prototype.OnNameUnavailable = function ()
	{
		return true;
	};
	
//cranberrygame end
	
	// ... other conditions here ...
	
	pluginProto.cnds = new Cnds();
	
	//////////////////////////////////////
	// Actions
	function Acts() {};

/*
	// the example action
	Acts.prototype.MyAction = function (myparam)
	{
		// alert the message
		alert(myparam);
	};
	
	//cranberrygame
	Acts.prototype.TriggerAction = function ()
	{
		var self = this;		
		self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.TriggerCondition, self);
	};	
*/
	
/*	
//cranberrygame start
	Acts.prototype.LogIn = function (permissions) //gizmodude4 - changed parameter to string
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbReady)
			return;	
		
		//gizmodude4 start
		if(fbLoggingIn)
		{
			console.log("Error: Attempted to login a second time. Ignoring second login attempt.");
			return;
		}
		
		//Graph API Explorer
		//https://developers.facebook.com/tools/explorer/145634995501895/?method=GET&path=me%3Ffields%3Did%2Cname&version=v2.1
		//https://developers.facebook.com/docs/graph-api/reference/v2.1
		//https://developers.facebook.com/docs/graph-api/reference/user/feed
		//https://developers.facebook.com/docs/graph-api/using-graph-api/v2.1#publishing		
		if (!fbLogined)
		{
			fbLoggingIn = true;
		//gizmodude4 end
			
			if (!window['cordova']) {
				//NOTE : Developers should call facebookConnectPlugin.browserInit(<appId>) before login - 
				//Web App ONLY (see Web App Guide): https://github.com/Wizcorp/phonegap-facebook-plugin/blob/master/platforms/web/README.md
				//var appId = prompt("Enter FB Application ID", "");
				facebookConnectPlugin['browserInit'](fbAppID);
			}
			//facebookConnectPlugin['login']( ["email"], //cranberrygame

			//permission: https://developers.facebook.com/docs/facebook-login/permissions/v2.2
			facebookConnectPlugin['login']( permissions.split(','), //cranberrygame
				function (result) { 
					//alert(JSON.stringify(result)) 
					console.log(result); //gizmodude4
					fbLoggingIn = false; //gizmodude4
					fbUserID = result["authResponse"]["userID"];
//cranberrygame start: contributued by lancel
					fbAccessToken = result["authResponse"]["accessToken"];
//cranberrygame end
					if (result["authResponse"])
						onFBLogin();
				},
				function (error) { 
					fbLoggingIn = false; //gizmodude4
					//console.log(JSON.stringify(error));
					if (typeof error == "string")
						errorMessage = error;				
					else if (error["errorMessage"])
						errorMessage = error["errorMessage"];
					else
						errorMessage = JSON.stringify(error);					
				}
			);	
		}
	};
	
	//gizmodude4 start
	Acts.prototype.RequestPermissions = function (fbPerms)
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbReady)
			return;
		
		if(fbLoggingIn)
			return;
		
		//Graph API Explorer
		//https://developers.facebook.com/tools/explorer/145634995501895/?method=GET&path=me%3Ffields%3Did%2Cname&version=v2.1
		//https://developers.facebook.com/docs/graph-api/reference/v2.1
		//https://developers.facebook.com/docs/graph-api/reference/user/feed
		//https://developers.facebook.com/docs/graph-api/using-graph-api/v2.1#publishing		

		//fbPerms = 'email';
		
		if (!window['cordova']) {
			//NOTE : Developers should call facebookConnectPlugin.browserInit(<appId>) before login - 
			//Web App ONLY (see Web App Guide): https://github.com/Wizcorp/phonegap-facebook-plugin/blob/master/platforms/web/README.md
			//var appId = prompt("Enter FB Application ID", "");
			facebookConnectPlugin['browserInit'](fbAppID);
		}
		
		facebookConnectPlugin['api']('/me/permissions', [], 
			function(result) {
				if (!result || result.error)
				{
					console.error(result);
					return;
				}
				var num_matched_permissions = 0;
				var split_perms = fbPerms.split(',');
				var perm_assoc = new Object();
				for (perm in split_perms)
				{
					if(split_perms.hasOwnProperty(perm))
					{
						perm_assoc[split_perms[perm]] = 1;
					}
				}
				var permissions_array = new Object();
				for (permission_num in result['data']) {
					if(perm_assoc.hasOwnProperty(result['data'][permission_num]['permission']))
					{
						num_matched_permissions++;
						console.log("already have permission "+result['data'][permission_num]['permission']);
					}
				}
				if(num_matched_permissions < split_perms.length)
				{
					fbLoggingIn = true;
					facebookConnectPlugin['login']( split_perms,
						function (result) { 
							console.log(result);
							fbUserID = result["authResponse"]["userID"];
							fbAccessToken = result["authResponse"]["accessToken"];
							fbLoggingIn = false;
							if (result["authResponse"])
								onFBLogin();
						},
						function (result) { 
							fbLoggingIn = false;
							console.log(result);
						}
					);	
				}
				else
				{
					console.log("Requesting no new permissions. Skipping permission request.");
				}
			},
			function(error) {
				//console.log(JSON.stringify(error));
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
			}			
		);				
	};
	
	Acts.prototype.GetPermissions = function ()
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;
			
		facebookConnectPlugin['api']('/me/permissions', [], 
			function(result) {
				//console.log(JSON.stringify(result)); 
			
				if (!result || result.error)
				{
					console.error(result);
					return;
				}
				for (permission_num in result['data']) {
					console.log(result['data'][permission_num]['permission']);
					console.log(result['data'][permission_num]['status']);
				}
			},
			function(error) {
				//console.log(JSON.stringify(error));
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
			}
		);
	};
	//gizmodude4 end
*/

	Acts.prototype.Login = function (permissions, tag) //gizmodude4 - changed parameter to string
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbReady)
			return;	
		
		if (fbLogined)
			return;
		
		//Graph API Explorer
		//https://developers.facebook.com/tools/explorer/145634995501895/?method=GET&path=me%3Ffields%3Did%2Cname&version=v2.1
		//https://developers.facebook.com/docs/graph-api/reference/v2.1
		//https://developers.facebook.com/docs/graph-api/reference/user/feed
		//https://developers.facebook.com/docs/graph-api/using-graph-api/v2.1#publishing
		if (!window['cordova']) {
			//NOTE : Developers should call facebookConnectPlugin.browserInit(<appId>) before login - 
			//Web App ONLY (see Web App Guide): https://github.com/Wizcorp/phonegap-facebook-plugin/blob/master/platforms/web/README.md
			//var appId = prompt("Enter FB Application ID", "");
			facebookConnectPlugin['browserInit'](fbAppID);
		}
		//facebookConnectPlugin['login']( ["email"], //cranberrygame

		var self = this;
		
		//permission: https://developers.facebook.com/docs/facebook-login/permissions/v2.2
		facebookConnectPlugin['login']( permissions.split(','), //cranberrygame
			function (result) { 
				//console.log(JSON.stringify(result)) 
				fbUserID = result["authResponse"]["userID"];
//cranberrygame start: contributued by lancel
				fbAccessToken = result["authResponse"]["accessToken"];
//cranberrygame end					
				fbLogined = true;
				
				curTag = tag;
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnLoginSucceeded, self);

				facebookConnectPlugin['api']('/me', [], 
					function (result) {
						//console.log(JSON.stringify(result))
						fbFullName = result["name"];
						fbFirstName = result["first_name"];
						fbLastName = result["last_name"];
						fbGender = result["gender"];
						fbUserID = result["id"];
		
						self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnNameAvailable, self);
					}, 
					function (error) {
						//console.log(JSON.stringify(error));
						if (typeof error == "string")
							errorMessage = error;				
						else if (error["errorMessage"])
							errorMessage = error["errorMessage"];
						else
							errorMessage = JSON.stringify(error);
					
						self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnNameUnavailable, self);
					}
				);
				
			},
			function (error) { 
				//console.log(JSON.stringify(error));
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
					
				curTag = tag;					
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnLoginFailed, self);						
			}
		);	
	};
	Acts.prototype.RequestPermissions = function (fbPerms)
	{
	}
	Acts.prototype.GetPermissions = function ()
	{
	}
	
	Acts.prototype.Logout = function ()
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;

		var self = this;
		facebookConnectPlugin['logout']( 
			function (result) { 
				//console.log(JSON.stringify(result)); 
				fbLogined = false;
				fbFullName = "";
				fbFirstName = "";
				fbLastName = "";
				fbGender = "";
				fbEmail = "";
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnLogoutSucceeded, self);
			},
			function (error) { 
				//console.log(JSON.stringify(error));
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);

				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnLogoutFailed, self);
			}
		);		
	};
	
	Acts.prototype.PromptWallPost = function ()
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;

		var self = this;		
		facebookConnectPlugin['showDialog']( { 'method': "feed" }, 
			function (result) { 
				console.log(JSON.stringify(result)) 
				//result["post_id"] //ex) 159903825364317_1607631796120296
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPromptWallPostSucceeded, self);				
			},
			function (error) { 
				onsole.log(JSON.stringify(error)) 
				//error["errorMessage"] //ex) User cancelled dialog
				//error["errorCode"] //ex) 4201
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);

				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPromptWallPostFailed, self);				
			}
		);		
	};
	
	Acts.prototype.PromptToShareApp = function (name_, description_, caption_, picture_)
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;
			
		var self = this;		
		facebookConnectPlugin['showDialog']({
			"method": "feed",
			"link": "http://apps.facebook.com/" + fbAppID + "/",
			"name": name_,
			"description": description_,
			"caption": caption_,
			"picture": picture_
			}, 
			function(result) {
				console.log(JSON.stringify(result));
				//result["post_id"] //ex) 159903825364317_1607631796120296
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPromptToShareThisAppSucceeded, self);				
			}, 
			function(error){
				console.log(JSON.stringify(error));
				//error["errorMessage"] //ex) User cancelled dialog
				//error["errorCode"] //ex) 4201
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
			
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPromptToShareThisAppFailed, self);				
			}
		);
	};
	
	Acts.prototype.PromptToShareLink = function (url_, name_, description_, caption_, picture_)
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;
			
		var self = this;		
		facebookConnectPlugin['showDialog']({
			"method": "feed",
			"link": url_,
			"name": name_,
			"description": description_,
			"caption": caption_,
			"picture": picture_
			}, 
			function(result) {
				console.log(JSON.stringify(result));
				//result["post_id"] //ex) 159903825364317_1607631796120296				
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPromptToShareLinkSucceeded, self);				
			}, 
			function(error){
				console.log(JSON.stringify(error));
				//error["errorMessage"] //ex) User cancelled dialog
				//error["errorCode"] //ex) 4201
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
					
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPromptToShareLinkFailed, self);				
			});
	};
	
	Acts.prototype.PublishWallPost = function (message_)
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;
	
		//http://stackoverflow.com/questions/1714786/querystring-encoding-of-a-javascript-object
		//https://github.com/Wizcorp/phonegap-facebook-plugin/issues/588
		//https://github.com/Wizcorp/phonegap-facebook-plugin/issues/524
		var serialize = function(obj) {
		  var str = [];
		  for(var p in obj)
			if (obj.hasOwnProperty(p)) {
			  str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
			}
		  return str.join("&");
		}
		//console.log(serialize({foo: "hi there", bar: "100%" })); //foo=hi%20there&bar=100%25		
		
		var publish = {
			"message": message_
		};
		
		var self = this;		
		facebookConnectPlugin['api']('/me/feed?method=post&' + serialize(publish), ['publish_actions'], 
			function (result) {
				console.log(JSON.stringify(result));
				//result["id"] //ex) "159903825364317_1607631796120296"
				
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPublishWallPostSucceeded, self);				
			}, 
			function (error) {
				console.log(JSON.stringify(error));
				//error //ex1) "Session: an attempt was made to request new permissions for a session that has a pending request"
				        //ex2) {"errorMessage":"Duplicate status message", "errorType":"FacebookApiException", "errorCode":"506"}
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
				
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPublishWallPostFailed, self);				
			}
		);
	};
	
	Acts.prototype.PublishLink = function (message_, url_, name_, description_, caption_, picture_)
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;
	
		//http://stackoverflow.com/questions/1714786/querystring-encoding-of-a-javascript-object
		//https://github.com/Wizcorp/phonegap-facebook-plugin/issues/588
		//https://github.com/Wizcorp/phonegap-facebook-plugin/issues/524
		var serialize = function(obj) {
		  var str = [];
		  for(var p in obj)
			if (obj.hasOwnProperty(p)) {
			  str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
			}
		  return str.join("&");
		}
		//console.log(serialize({foo: "hi there", bar: "100%" })); //foo=hi%20there&bar=100%25		
		
		var publish = {
			"message": message_,
			"link": url_,
			"name": name_,
			"description": description_,
			"caption": caption_
		};
		if (picture_.length)
			publish["picture"] = picture_;

/*
		var publish = {};
		if (message_)
			publish["message"] = message_;
		if (url_)
			publish["link"] = url_;
		if (name_)
			publish["name"] = name_;
		if (description_)
			publish["description"] = description_;
		if (caption_)
			publish["caption"] = caption_;
		if (picture_)
			publish["picture"] = picture_;			
*/
			
		var self = this;			
		facebookConnectPlugin['api']('/me/feed?method=post&' + serialize(publish), ['publish_actions'], 
			function (result) {
				console.log(JSON.stringify(result));
				//result["id"] //ex) "159903825364317_1607631796120296"
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPublishLinkSucceeded, self);					
			}, 
			function (error) {
				console.log(JSON.stringify(error));
				//error //ex1) "Session: an attempt was made to request new permissions for a session that has a pending request"
				        //ex2) {"errorMessage":"Duplicate status message", "errorType":"FacebookApiException", "errorCode":"506"}
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
					
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPublishLinkFailed, self);				
			}
		);			
	};
	
	Acts.prototype.PublishScore = function (score_)
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;

		//http://stackoverflow.com/questions/1714786/querystring-encoding-of-a-javascript-object
		//https://github.com/Wizcorp/phonegap-facebook-plugin/issues/588
		//https://github.com/Wizcorp/phonegap-facebook-plugin/issues/524
		var serialize = function(obj) {
		  var str = [];
		  for(var p in obj)
			if (obj.hasOwnProperty(p)) {
			  str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
			}
		  return str.join("&");
		}
		//console.log(serialize({foo: "hi there", bar: "100%" })); //foo=hi%20there&bar=100%25		
		
		var publish = {
			"score": Math.floor(score_)
		};
		
		var self = this;		
		facebookConnectPlugin['api']('/me/scores?method=post&' + serialize(publish), ['publish_actions'], 
			function (result) {
				console.log(JSON.stringify(result));
				//result["success"] //ex) true					
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPublishScoreSucceeded, self);				
			}, 
			function (error) {
				console.log(JSON.stringify(error));
				//error //ex1) "Session: an attempt was made to request new permissions for a session that has a pending request"
				        //ex2) {"errorMessage":"Duplicate status message", "errorType":"FacebookApiException", "errorCode":"506"}
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
					
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnPublishScoreFailed, self);				
			}
		);		
	};
	
	Acts.prototype.RequestUserHiscore = function ()
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;
		
		var self = this;
		//my high scores for all apps
		facebookConnectPlugin['api']('/me/scores', [], 
			function(result) {
				console.log(JSON.stringify(result));
/*
{"data":[
{
"score":5, "user":{"id":"1401934583460016", "name":"Betty Amicjdfchchd Martinazzisky"}, "application": {"id":"1288298811490896", "name":"Avoid Bird"}
}
]}
*/		
				fbScore = 0;
				var arr = result["data"];
				
				if (!arr)
				{
					console.error("Request for user hi-score failed: " + result);
					return;
				}
				
				var i, len;
				for (i = 0, len = arr.length; i < len; i++)
				{
					if (arr[i]["score"] > fbScore)
						fbScore = arr[i]["score"];
				}
				
				self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnUserTopScoreAvailable, self);
				
				if (!result || result.error) {
					console.error(result);
				} 
				else {
					log(result);
				}
			},
			function (error) {
				console.log(JSON.stringify(error));
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
			}
		);
	};
	
	Acts.prototype.RequestHiscores = function (n)
	{
		if (!(this.runtime.isAndroid || this.runtime.isiOS))
			return;			
        if (typeof facebookConnectPlugin == 'undefined')
            return;
			
		if (!fbLogined)
			return;
			
		var self = this;
		//friends' high scores for specific app
		//The user_friends permission is required 
		//https://developers.facebook.com/docs/games/scores
		facebookConnectPlugin['api']('/' + fbAppID + '/scores', [], 
			function(result) {
				console.log(JSON.stringify(result));
/*
{"data":[
{
"score":5, "user":{"id":"1401934583460016", "name":"Betty Amicjdfchchd Martinazzisky"}, "application": {"id":"1288298811490896", "name":"Avoid Bird"}
},
{
"score":4, "user":{"id":"1401934581110022", "name":"Jack Agfgfgchchd Hdffinazzisky"}, "application": {"id":"1288298811490896", "name":"Avoid Bird"}
}
]}
*/		
				var arr = result["data"];
				
				if (!arr) {
					console.error("Hi-scores request failed: " + result);
					return;
				}
				
				arr.sort(function(a, b) {
					// descending order
					return b["score"] - a["score"];
				});
				
				var i = 0, len = Math.min(arr.length, n);
				
				for ( ; i < len; i++) {
					fbScore = arr[i]["score"];
					fbHiscoreName = arr[i]["user"]["name"];
					fbHiscoreUserID = arr[i]["user"]["id"];
					fbRank = i + 1;
					self.runtime.trigger(cr.plugins_.cranberrygame_PhonegapFacebook.prototype.cnds.OnHiscore, self);
				}
				
				if (!result || result.error) {
					console.error(result);
				} 
				else {
					log(result);
				}
			},
			function (error) {
				console.log(JSON.stringify(error));
				if (typeof error == "string")
					errorMessage = error;				
				else if (error["errorMessage"])
					errorMessage = error["errorMessage"];
				else
					errorMessage = JSON.stringify(error);
			}
		);
	};
//cranberrygame end
	
	// ... other actions here ...
	
	pluginProto.acts = new Acts();
	
	//////////////////////////////////////
	// Expressions
	function Exps() {};
	
/*	
	// the example expression
	Exps.prototype.MyExpression = function (ret)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		ret.set_int(1337);				// return our value
		// ret.set_float(0.5);			// for returning floats
		// ret.set_string("Hello");		// for ef_return_string
		// ret.set_any("woo");			// for ef_return_any, accepts either a number or string
	};
	
	Exps.prototype.Text = function (ret, param) //cranberrygame
	{     
		ret.set_string("Hello");		// for ef_return_string
		//ret.set_int(1337);				// return our value
		// ret.set_float(0.5);			// for returning floats
		// ret.set_string("Hello");		// for ef_return_string
		// ret.set_any("woo");			// for ef_return_any, accepts either a number or string		
	};	
*/
	
//cranberrygame start
	Exps.prototype.FullName = function (ret)
	{
		ret.set_string(fbFullName);
	};
	
	Exps.prototype.FirstName = function (ret)
	{
		ret.set_string(fbFirstName);
	};
	
	Exps.prototype.LastName = function (ret)
	{
		ret.set_string(fbLastName);
	};
	
	Exps.prototype.Score = function (ret)
	{
		ret.set_int(fbScore);
	};
	
	Exps.prototype.HiscoreName = function (ret)
	{
		ret.set_string(fbHiscoreName);
	};
	
	Exps.prototype.HiscoreUserID = function (ret)
	{
		ret.set_int(fbHiscoreUserID);
	};
	
	Exps.prototype.HiscoreRank = function (ret)
	{
		ret.set_int(fbRank);
	};
	
	Exps.prototype.UserID = function (ret)
	{
		// Float because these numbers are insanely huge now!
		ret.set_float(parseFloat(fbUserID));
	};
	
//cranberrygame start: contributued by lancel	
	Exps.prototype.AccessToken = function (ret)
	{
		ret.set_string(fbAccessToken);
	};
//cranberrygame end	
//cranberrygame end
	
	Exps.prototype.Email = function (ret)
	{
		ret.set_string(fbEmail);
	};
	
	Exps.prototype.Gender = function (ret)
	{
		ret.set_string(fbGender);
	};

	//
	Exps.prototype.ErrorMessage = function (ret)
	{
		ret.set_string(errorMessage);
	};
	
	// ... other expressions here ...
	
	pluginProto.exps = new Exps();

}());